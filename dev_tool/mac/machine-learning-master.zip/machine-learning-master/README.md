# machine-learning
### Machine Learning class project in Java.
### Variations of neural network algorithms implementations.
#### Use ./build.bash to compile and run.
#### Unzip the content of data folder in project 7.
