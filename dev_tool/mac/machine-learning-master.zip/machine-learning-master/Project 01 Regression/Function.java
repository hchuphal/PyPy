abstract public class Function 
{

	abstract double evaluate(double[] in);

}